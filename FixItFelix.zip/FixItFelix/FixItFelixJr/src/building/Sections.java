package building;

public enum Sections
{
	FIRST, SECOND, THIRD;
}