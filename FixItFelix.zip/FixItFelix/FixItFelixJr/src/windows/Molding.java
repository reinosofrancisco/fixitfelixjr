package windows;


import util.Direction;


class Molding extends Obstacle
{
	private static Direction dir= Direction.UP;
	Molding()
	{
		super(dir);
	}

}
