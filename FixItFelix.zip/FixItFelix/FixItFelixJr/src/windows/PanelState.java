package windows;

enum PanelState 
{
	HEALTHY,BROKEN, ALMOSTBROKEN;
}
