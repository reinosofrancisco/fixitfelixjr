package game;

public enum FelixState {
	KILLEDBYBIRD,
	KILLEDBYBRICK,
	INMUNITY,
	DEFAULT;
}
